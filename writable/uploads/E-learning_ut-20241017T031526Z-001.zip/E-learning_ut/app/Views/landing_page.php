<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Landing Page E-Learning Kampus</title>
    <link rel="stylesheet" href="<?= base_url('assets/css/style.css'); ?>">
    <!-- Tambahkan link ke Bootstrap atau CSS lainnya jika diperlukan -->
</head>
<body>
    <header>
        <nav>
            <h1>Universitas terbuka</h1>
            <h2>Selamat Datang Di File Manager Materi Pengayaan Universitas Terbuka</h2>
            <p>Belajar secara online dengan berbagai materi kuliah yang tersedia.</p>
        </nav>
    </header>

    <section id="hero">
        <div class="container">
           
            <ul>
                <li><a href="#">FE</a></li>
                <li><a href="#">FHISIP</a></li>
                <li><a href="#">FKIP</a></li>
                <li><a href="#">FST</a></li>
                <li><a href="#">PPS</a></li>
            </ul>
        </div>
    </section>
<footer></footer>
    
    
</body>
</html>
