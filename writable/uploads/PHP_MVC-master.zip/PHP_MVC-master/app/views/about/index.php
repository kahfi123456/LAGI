<div class="container mt-4">
	<img src="<?= BASEURL; ?>/img/me.jpg" alt="Isep Lutpi Nur" width=200>
	<br>
	Hallo, Saya <?= $data['nama']; ?> saya seorang <?= $data['pekerjaan']; ?> dan sekarang umur saya <?= $data['umur']; ?> tahun
</div>

