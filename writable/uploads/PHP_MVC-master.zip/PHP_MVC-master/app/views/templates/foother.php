        <div class="container-fluid">
            <footer class="pt-4 my-md-4 pt-md-3 border-top">
                <div class="row">
                    <div class="col-12 col-md center">
                        &copy; 2020 - <a class="text-info" href="">Isep Lutpi Nur</a>
                    </div>
                </div>
            </footer>
        </div>
    <script type="text/javascript" src="<?= BASEURL; ?>/js/jquery-3.3.1.js"></script>
	<script type="text/javascript" src="<?= BASEURL; ?>/js/bootstrap.min.js"></script>
    <script type="text/javascript" src="<?= BASEURL; ?>/js/script.js"></script>
</body>
</html>
