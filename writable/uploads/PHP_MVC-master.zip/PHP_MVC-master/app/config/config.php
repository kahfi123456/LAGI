<?php
define('BASEURL', 'http://localhost/aplikasi/PHP%20MVC/WPU/public');

// Database
define('DB_HOST', 'localhost');
define('DB_USERNAME', 'root');
define('DB_PASSWORD', '');
define('DB_NAME', 'wpu_phpdasar');
