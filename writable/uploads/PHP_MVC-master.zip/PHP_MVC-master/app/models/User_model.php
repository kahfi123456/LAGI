<?php 
class User_model{
	private $nama = 'Isep Lutpi Nur';

	public function getUser(){
		return $this->nama;
	}
}
